# KDOS 畅捷通 T+19.0 只读 Skill

这是一个供 Codex 使用的**本地 Skill 安装包**，面向凯南数字化/KDOS 的 T+ 双账套查询，重点是科加智能 (`UFTData418971_000003`) 的工艺路线、BOM、工序。

## 安装

压缩包包含 `.agents/skills/kdos-tplus-readonly/`，解压到你的 **knweb 项目根目录**，不覆盖同名现有 Skill。原始 CHM 保留在 `assets/` 下供离线查阅，不含凭据。

该包尚未安装到你服务器，也未向 GitHub 提交。

## 第一件事：先只读检查科加工艺表

在 Codex 中让它阅读 `.agents/skills/kdos-tplus-readonly/SKILL.md`，检查当前仓库的 AGENTS、真实连接、账号信息。

或在服务器已有的 Python 环境中运行（只打印元数据，不写入数据）：

```bash
cd /data/automation/code/work/PMC/knweb
PYTHONPATH=/data/automation/code/work/basci/basic_code \
  /data/automation/code/work/basci/basic_code/.venv/bin/python \
  .agents/skills/kdos-tplus-readonly/scripts/inspect_kejia_routing.py
```

注意：源码中的 `basic_code` 环境与 SSH 隧道配置仍要以服务器现状为准。命令不会调用同步 API，不会写入目标 KDOS 数据库，也不会创建生产任务。

如果需要读取少量路线样例，在明确列名和敏感信息口径之后再执行：

```bash
PYTHONPATH=/data/automation/code/work/basci/basic_code \
  /data/automation/code/work/basci/basic_code/.venv/bin/python \
  .agents/skills/kdos-tplus-readonly/scripts/inspect_kejia_routing.py --sample AA_Routing
```

## 字典

- `scripts/chm_index.py --metadata` 不需 7z，可以确认文件目录及散列值。
- `scripts/chm_index.py --extract` 需要系统预先具备 `7z`、`7zz` 或 `extract_chmLib`，按关键词生成索引。
- 本轮仅完成原始 CHM 的容器结构解析；**没有成功提取并验证 HTML 正文**，因此字段 JOIN 未被写死。

## 当前交付范围

- 原始 CHM 数据字典原封保存；可在支持 CHM 的机器上离线解析。
- `SKILL.md`：使用约束、已确认账套配置、工作流程与安全规则。
- `references/`：候选表证据表、CHM 状态和只读 SQL 模板。
- `scripts/`：实际项目复用型只读查询脚本、CHM 解压/索引脚本。

没有连接你的生产数据库，没有测试真实业务数据，没有修改 knweb 源码、Git 状态或数据库。
